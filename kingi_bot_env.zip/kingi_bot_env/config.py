TOKEN = '7515094075:AAFFrS2Y3_-1uy-wfQeitU9D8veY49hZnaA'
WEBHOOK_URL = 'https://kgsd.site/public_html/main.py/'
DATABASE_URL = 'postgresql://username:password@localhost/database_name'
POINTS_PER_TAP = 1
TAP_COOLDOWN = 10800  # 3 hours in seconds
BOOST_LIMIT = 3
BOOST_COST = 0.1